### v1.0.0.6

* Version enforcement 70715 -> 70716
* Added Checkpoint
* MN start fix

Sample configuration files for:

SystemD: tradecoind.service
Upstart: tradecoind.conf
OpenRC:  tradecoind.openrc
         tradecoind.openrcconf
CentOS:  tradecoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.

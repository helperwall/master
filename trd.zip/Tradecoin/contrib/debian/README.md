
Debian
====================
This directory contains files used to package tradecoind/tradecoin-qt
for Debian-based Linux systems. If you compile tradecoind/tradecoin-qt yourself, there are some useful files here.

## tradecoin: URI support ##


tradecoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install tradecoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your tradecoinqt binary to `/usr/bin`
and the `../../share/pixmaps/tradecoin128.png` to `/usr/share/pixmaps`

tradecoin-qt.protocol (KDE)


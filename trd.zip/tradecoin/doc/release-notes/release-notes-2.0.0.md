### v2.0.0

* Added new global seed nodes: seed[1-3].tradecoin.team
* Added new branding
* Community vote result: reduced max coin supply to 25.000.000 TRADE
* Community vote result: changed reward distribution to 70% MN and 30% PoS
  after block 205000
* Community vote result: changed reward structure to Proposal 1: 3f1ee87
* Updated README.md with coin specifications: https://github.com/Tradecoin-Project/tradecoin/blob/master/README.md
* Merged PIVX 3.1.1 toolchain to simplify cross compilation
* Enabled version enforcement to disconnect pre-2.x clients
* Enabled all architectures for compiling

### v1.0.0.4

* MN collateral change

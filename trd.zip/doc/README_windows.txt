Tradecoin Core
============

Intro
-----

Tradecoin (TRADE) is an open-source Proof-of-Work digital cryptocurrency for
fast (using SwiftX), private (Zerocoin protocol) and secure microtransactions.
Our main goal is to create a decentralized fully secure and anonymous network
to run applications which do not rely on any central body control. By having
a distributed system, thousands of users will be responsible for maintaining
the application and data so that there is no single point of failure.

Setup
-----

Unpack the files into a directory and run 'usr/bin/tradecoin-qt.exe'.

Tradecoin Core is the original Tradecoin client and it builds the backbone of the
network. However, it downloads and stores the entire history of Tradecoin
transactions; depending on the speed of your computer and network connection,
the synchronization process can take anywhere from a few hours to a day or
more.
